#!/bin/bash
 
#SBATCH --reservation=ws_gpu
#SBATCH --partition=agro-b,mcordgpu-b
#SBATCH --cpus-per-task=6
#SBATCH --gpus=1
#SBATCH --mem=40000
#SBATCH --time=0-3:0:00
 
# Load requested software stack
module load SBEnv
module load cuda/12.4.1 arch/avx2 gcc/13.2.0
module load python/3.12



# now actiate the environment
source hf/bin/activate


echo "Starting run at: `date`"

python ./diffusers/examples/text_to_image/train_text_to_image_lora.py  --pretrained_model_name_or_path runwayml/stable-diffusion-v1-5   --train_data_dir dataset2/train   --output_dir lora-sd-output2   --resolution 512   --train_batch_size 1   --max_train_steps 1200

echo "Program finished with exit code ${?} at: `date`"


#
