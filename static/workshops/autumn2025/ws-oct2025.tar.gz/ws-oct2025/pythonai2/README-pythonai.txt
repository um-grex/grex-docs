
After copying notebooks to your PROJECT directory ( /home/{user}/projects/def-{PI}/{user}/pythonai ),

1) Start a Jupyter Notebook job on Grex's OpenOnDemand portal ( https://ood.hpc.umanitoba.ca ). 
	Pick the WS 25 App
	Pick 1 GPU, Reservation ws_gpu or none, and 8 CPUs.
	Pick a GPU partition (agro-b or mcordgpu-b)

2) open the notebook 1 ; use Lmod's tab to load "arrow" and "boost" modules. Add "--no-index" to "pip" command, add version to torch (torch==2.8.0 ); run the cells for text generation exercise.



4) Now we need to create text-mode Python calculation for interactive job to do LoRa training. 
    Close the Jupyter Notebook job in Ondemand to free the GPU
    Open the OOD Shell app on Grex's OnDemand.
    Follow instructions on https://um-grex.github.io/grex-docs/training/workshops-2025/lora-huggingface 

5) Start again a Jupyter Notebook job on Grex's OpenOnDemand portal ( https://ood.hpc.umanitoba.ca ). 
	Pick the WS 25 App
	Pick 1 GPU, Reservation ws_gpu or none, and 8 CPUs.
	Pick a GPU partition (agro-b or mcordgpu-b)

6) open the notebook 3 ; use Lmod's tab to load "arrow" and "boost" modules. Add "--no-index" to "pip" command, add version to torch (torch==2.8.0); run the cells for text generation exercise. 
    
