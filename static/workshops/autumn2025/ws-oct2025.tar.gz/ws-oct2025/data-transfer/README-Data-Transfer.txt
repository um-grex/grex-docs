This directory lists the instructions for transferring files 
and directories using the command line with scp:

* Create a test file and directory:

- If you do not have any test file or directory, create one 
  by running the following commands from your terminal, 
  as follow:

'''
mkdir -p TestDir
touch TestDir/testfile.txt
echo "Test file for data transfer:" > TestDir/testfile.txt
echo "UManitoba Spring Workshop: Oct 2025." >> TestDir/testfile.txt
'''

* Alternatively, use wget to download, for example, STAR: 

'''
mkdir -p TestDir
wget https://github.com/alexdobin/STAR/archive/refs/tags/2.7.11b.tar.gz
cd ..
'''

* Alternatively, use git clone to clone the repo from GitHub, 
  for example: clone the GitHub repo of the program STAR.

'''
mkdir -p TestDir
cd TestDir
git clone https://github.com/alexdobin/STAR.git
cd ..
'''

- Now, list the file and directories:

'''
ls TestDir/
'''

* Inspect the size of the directory:

du -sh TestDir

- Now, copy the directory to MC or any other cluster using scp:

'''
scp -r TestDir your_username@login1.demo.hpc.umanitoba.ca:~/
scp -r TestDir your_username@login1.demo.hpc.umanitoba.ca:~/scratch/
scp -r TestDir your_username@other-cluster:~/
...
'''

- Now copy back the TestDir from the remote machine to 
  a new directory {MyArchive} on your local machine: 

'''
mkdir -p MyArchive
scp -r your_username@login1.demo.hpc.umanitoba.ca:~/TestDir MyArchive/
scp -r your_username@other-cluster:~/TestDir MyArchive/
'''

- Instead of transferring a directory, create an archive and 
  transfer it to a cluster:

'''
tar -cvf TestDir.tar TestDir
ls 
scp -r TestDir.tar your_username@login1.demo.hpc.umanitoba.ca:~/
'''

Notes: 
  - When transferring a large number of small files, it is better to prepare 
    an archive {using tar} and transfer it instead of transferring the small 
    files separately.
  - It takes less time to tansfer the archive than the files it contains separately.

