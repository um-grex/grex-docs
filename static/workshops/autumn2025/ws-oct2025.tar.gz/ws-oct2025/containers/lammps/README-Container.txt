* Pull the conainer from NVIDIA page:

  https://catalog.ngc.nvidia.com/orgs/hpc/containers/lammps

* On Grex, use:
  
  module load singularity
  singularity pull docker://nvcr.io/hpc/lammps:patch_3Nov2022
 
  - It takes about 5 minutes
  - It generate the image: lammps_patch_3Nov2022.sif (about 560M)

* On the MC/CC clusters:

  module load apptainer
  apptainer pull docker://nvcr.io/hpc/lammps:patch_3Nov2022

  - It takes about 5 or 6 minutes or more depending on the network.
  - It generate the image: lammps_patch_3Nov2022.sif (about 560M)
