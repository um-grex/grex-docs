Here are the steps to rum LAMMPS using interactive job on Grex:

* Requirements: 
  - apptainer module: module load apptainer
  - Image: lammps_patch_3Nov2022.sif 
    {see the file: README-Container.txt for more information}
  - Input file: in.lj 
  - script to run lammps: ./run_lammps.sh

* Copy the image from the shared folder:

cp /home/shared/ws-may2025/images/lammps_patch_3Nov2022.sif .

- First, ask for interactive job using salloc:

  salloc --gpus=1 --cpus-per-gpu=1 --mem=8000 --time=1:00:00

- Once the job is granted, run the commands: 

    hostname
    nvidia-smi
    sq

    {the above should show the node and your interactive job}


* Running lammps:

module load apptainer
singularity run --nv -B $PWD:/host_pwd --pwd /host_pwd ./lammps_patch_3Nov2022.sif ./run_lammps.sh

* From another terminal, connect to the node where your job is running and run the command: 
  nvidia-smi to see if your program is using the GPU.

* Alternatively, submit the job using sbatch:

  sbatch mc-submit-lmp-gpu.sh

