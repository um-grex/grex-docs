#!/bin/bash

#SBATCH --gpus=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8000M
#SBATCH --time=0-1:00:00
#SBATCH --job-name=GPU

#Load the modules:

module load singularity

echo "Starting run at: `date`"

singularity run --nv -B $PWD:/host_pwd --pwd /host_pwd ./lammps_patch_3Nov2022.sif ./run_lammps.sh

echo "Program finished with exit code $? at: `date`"
