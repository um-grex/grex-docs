On Grex:

* To build the image, use:

module load singularity
singularity pull library://sylabsed/examples/lolcow

* Alternatively, copy the image:

cp /global/software/ws-may2025/images/lolcow_latest.sif .

* Run the commands:

singularity run lolcow_latest.sif
singularity inspect lolcow_latest.sif
singularity inspect --runscript lolcow_latest.sif
singularity inspect --deffile lolcow_latest.sif
singularity exec lolcow_latest.sif  apt list --installed
singularity exec lolcow_latest.sif  awk 'BEGIN {print "Hello World"}'

On MC:

salloc --mem=8000m --time=1:00:00

module load apptainer

Copy the image from the shared folder:

cp -r /home/shared/ws-may2025/images/lolcow_latest.sif .

Run the commands:

singularity run lolcow_latest.sif
singularity inspect lolcow_latest.sif
singularity inspect --runscript lolcow_latest.sif
singularity inspect --deffile lolcow_latest.sif
singularity exec lolcow_latest.sif  apt list --installed
singularity exec lolcow_latest.sif  awk 'BEGIN {print "Hello World"}'

