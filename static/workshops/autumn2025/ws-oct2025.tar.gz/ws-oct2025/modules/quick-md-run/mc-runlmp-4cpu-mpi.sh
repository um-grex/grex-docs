#!/bin/bash

module load StdEnv/2023  intel/2023.2.1  openmpi/4.1.5 lammps-omp/20240829

mpirun -np 4 lmp -in lammps-input.in -log output_lammps-mpi-4cpus.txt

