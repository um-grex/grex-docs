* A quick test to run from login node.

* Requireements: - access to login or compute node {via salloc}
                 - access the module {lammps in this case}
                 - Input file: lammps-input.in
 
* First, connect to a cluster: MC or CC or Grex
  
A. On MC / CC clusters: 

   - Module "lammps-omp/20240829":
   - Run the following commands:

     module purge
     module spider lammps-omp/20240829

     Then load the module "lammps-omp/20240829"

     module load StdEnv/2023  intel/2023.2.1  openmpi/4.1.5 lammps-omp/20240829

     See if the module is loaded by running: module list

   - The binary for this program is called "lmp"
   - See if the binary is in your path by running the command:

     which lmp

   - Now try to run the test interactively by invoking the commands:

     lmp -in lammps-input.in
     
B. On Grex, load the following modules:

   module load arch/avx512  gcc/13.2.0  openmpi/4.1.6 lammps/2024-08-29p1

   See if the module is loaded by running: module list

   - The binary for this program is called "lmp"
   - See if the binary is in your path by running the command:

     which lmp

   - Now try to run the test interactively by invoking the commands:

     lmp -in lammps-input.in

Running the program using scripts:

Notes: - Scripts starting with "grex-*" are set to run on Grex.
       - Scripts starting with "mc-*" are set to run on MC/CC clusters.

* Before running any script, have a look at using a text editor or using cat:

  cat <your script>
   
* On Grex: 

  sh ./grex-runlmp-1cpu-serial.sh
  sh ./grex-runlmp-2cpu-openmp.sh
  sh ./grex-runlmp-2cpu-mpi.sh
  sh ./grex-runlmp-4cpu-openmp.sh
  sh ./grex-runlmp-4cpu-mpi.sh 

* On MC / CC Cluster:

  sh ./mc-runlmp-1cpu-serial.sh
  sh ./mc-runlmp-2cpu-openmp.sh
  sh ./mc-runlmp-2cpu-mpi.sh
  sh ./mc-runlmp-4cpu-openmp.sh
  sh ./mc-runlmp-4cpu-mpi.sh

* The above will run lammps using:

  - 1 CPU   ==> Serial program
  - 2 CPUs  ==> OpenMP program
  - 2 CPUs  ==> MPI program
  - 4 CPUs  ==> OpenMP program
  - 4 CPUs  ==> MPI program

* The above will generate the following output:

  output_lammps-serial.txt
  output_lammps-openmp-2cpus.txt
  output_lammps-mpi-2cpus.txt
  output_lammps-openmp-4cpus.txt
  output_lammps-mpi-4cpus.txt

Done.
