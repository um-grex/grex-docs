#!/bin/bash

module load arch/avx512  gcc/13.2.0  openmpi/4.1.6 lammps/2024-08-29p1

mpirun -np 2 lmp -in lammps-input.in -log output_lammps-mpi-2cpus.txt

