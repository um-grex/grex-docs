#!/bin/bash

module load arch/avx512  gcc/13.2.0  openmpi/4.1.6 lammps/2024-08-29p1

export OMP_NUM_THREADS=4

lmp -sf omp -in lammps-input.in -log output_lammps-openmp-4cpus.txt

