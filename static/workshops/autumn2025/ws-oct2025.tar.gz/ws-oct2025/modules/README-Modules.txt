* Software and Modules:

What to do:

1. Connect to a cluster: MC / Grex / CC cluster

2. Try to search and load some modules.

- Here is a list of the programs to search for:

  * gcc
  * boost
  * netcdf
  * python
  * gromacs
  * geant4
  * lammps
  * or any other program you have in mind.
  * ... etc.

- For each program, run the following commands:

  module purge
  module list
  module spider <program>
  
  * Read the message on your screen and type the commands to load this 
    particular module or a particular version.
    There is a possibility that the module does not exist!

  module load ... 

  * After loading a module, experiment with the following commands:

  module list
  module whatis <program>
  module help <program>
  module show <program>
  
  * Inspect the output: environment variables, paths, ...

  * Unload the module:

  module rm <program>

  or

  module unload <program>

  to remove <program> from your environment and list the 
  modules using: module list

  * Once done, you can run "module purge" to retrieve the 
    default environment.

- Repeat the exercise for any other programs you are interseted in.

