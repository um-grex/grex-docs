#!/bin/bash

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=500M
#SBATCH --time=0-0:08:00
#SBATCH --job-name=Serial

# Load the modules:

module load arch/avx512  gcc/13.2.0  openmpi/4.1.6 lammps/2024-08-29p1

echo "Starting run at: `date`"

lmp -in lammps-input.in -log output_lammps-serial-${SLURM_JOBID}.txt

echo "Program finished with exit code $? at: `date`"
