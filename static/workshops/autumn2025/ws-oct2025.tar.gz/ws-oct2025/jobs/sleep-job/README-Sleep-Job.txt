
* A first test of batch job:

Files: grex-sleep-job.sh  mc-sleep-job.sh  README-Sleep-Job.txt

Sleep Job: example of sleep job

* On MC/CC:

  - Inspect the script using: 
    cat mc-sleep-job.sh

  - Submit the script using:
    sbatch mc-sleep-job.sh
 
  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Once the job is done, inspect the output: slurm-<JobID>.out
    to see the environment variables set by slurm.

* On Grex:
  + You need to specify the partition, like genoa with:

    --partition=genoa
  
  - Inspect the script using:
    cat grex-sleep-job.sh

  - Submit the script using:
    sbatch [+options] grex-sleep-job.sh 

  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Once the job is done, inspect the output: slurm-<JobID>.out
    to see the environment variables set by slurm.
