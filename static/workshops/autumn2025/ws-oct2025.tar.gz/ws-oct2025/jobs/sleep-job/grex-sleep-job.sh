#!/bin/bash

echo "Starting run at: `date`"

echo "Running sleep command for 120 s"

sleep 120

env | grep SLURM > environment-var-slurm.txt 

echo "Program finished with exit code $? at: `date`"
