#!/bin/bash

module load arch/avx512  gcc/13.2.0  openmpi/4.1.6 lammps/2024-08-29p1

echo "Starting run at: `date`"

mpirun -np 4 lmp -in lammps-input.in -log output_lammps-serial-${SLURM_JOBID}.txt

echo "Program finished with exit code $? at: `date`"
