Serial job: example of serial jobs using lammps module
Requires: - lammps module
          - input file: lammps-input.in

* On MC/CC:

  - Inspect the script using: 
    cat mc-runlmp-1cpu-serial.sh

  - Submit the script using:
    sbatch [+options] mc-runlmp-1cpu-serial.sh
 
  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

* On Grex:
  + You need to specify the partition, like genoa with:

    --partition=genoa
  
  - Inspect the script using:
    cat grex-runlmp-1cpu-serial.sh

  - Submit the script using:
    sbatch [+options] grex-runlmp-1cpu-serial.sh

  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

* What was the slurm message?
  - How to resolve it?

