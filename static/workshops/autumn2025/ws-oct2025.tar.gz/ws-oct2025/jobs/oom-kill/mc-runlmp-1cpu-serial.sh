#!/bin/bash

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=500M
#SBATCH --time=0-0:05:00
#SBATCH --job-name=OOM

# Load the modules:

module load StdEnv/2023  intel/2023.2.1  openmpi/4.1.5 lammps-omp/20240829

echo "Starting run at: `date`"

lmp -in lammps-input.in -log output_lammps-serial-${SLURM_JOBID}.txt

echo "Program finished with exit code $? at: `date`"
