#!/bin/bash

#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --mem=3000M
#SBATCH --time=0-1:30:00
#SBATCH --job-name=MPI

# Load the modules:

module load StdEnv/2023  intel/2023.2.1  openmpi/4.1.5 lammps-omp/20240829

echo "Starting run at: `date`"

export OMP_NUM_THREADS=1

srun lmp -in lammps-input.in -log output_lammps-mpi-${SLURM_NTASKS}cpus-${SLURM_JOBID}.txt

echo "Program finished with exit code $? at: `date`"
