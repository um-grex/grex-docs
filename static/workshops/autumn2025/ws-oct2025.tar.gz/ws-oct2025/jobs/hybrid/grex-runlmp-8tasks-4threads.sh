#!/bin/bash

#SBATCH --ntasks=8
#SBATCH --cpus-per-task=4
#SBATCH --mem=3000M
#SBATCH --time=0-1:30:00
#SBATCH --job-name=Hybrid

# Load the modules:

module load arch/avx512  gcc/13.2.0  openmpi/4.1.6 lammps/2024-08-29p1

echo "Starting run at: `date`"

export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}

output=output_lammps-${SLURM_NTASKS}tasks-${SLURM_JOBID}-${SLURM_NNODES}nodes-${SLURM_CPUS_PER_TASK}threads.txt

mpirun -np ${SLURM_NTASKS} lmp -sf omp -pk omp ${SLURM_CPUS_PER_TASK} -in lammps-input.in -log ${output}

echo "Program finished with exit code $? at: `date`"
