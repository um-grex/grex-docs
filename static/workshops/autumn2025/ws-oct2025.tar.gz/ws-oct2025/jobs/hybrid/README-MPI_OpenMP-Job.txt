
grex-runlmp-16tasks-2threads.sh  grex-runlmp-8tasks-4threads.sh  mc-runlmp-32cpu-mpi.sh
grex-runlmp-32cpu-mpi.sh         mc-runlmp-16tasks-2threads.sh   mc-runlmp-8tasks-4threads.sh


MPI+OpenMP job: example of hybrid job using MPI and OpenMP

Requires: - lammps module
          - input file: lammps-input.in

* Scripts: Total CPUs = 32

   *-runlmp-16tasks-2threads.sh  ===> 16 MPI Tasks and 2 Threads/Task 
   *-runlmp-32cpu-mpi.sh         ===> 32 MPI Tasks and 1 Thread/Task
   *-runlmp-8tasks-4threads.sh   ===>  8 MPI Tasks and 4 Threads/Task

* On MC/CC:

  - Inspect the scripts using:

    cat mc-runlmp-16tasks-2threads.sh
    cat mc-runlmp-32cpu-mpi.sh
    cat mc-runlmp-8tasks-4threads.sh

  - Submit the script using:
    sbatch mc-runlmp-16tasks-2threads.sh
    sbatch mc-runlmp-32cpu-mpi.sh
    sbatch mc-runlmp-8tasks-4threads.sh
 
  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

* On Grex:
  + You need to specify the partition, like genoa with:

    --partition=genoa
  
  - Inspect the script using:

    cat grex-runlmp-16tasks-2threads.sh
    cat grex-runlmp-32cpu-mpi.sh
    cat grex-runlmp-8tasks-4threads.sh

  - Submit the script using:

    sbatch [+options] grex-runlmp-16tasks-2threads.sh
    sbatch [+options] grex-runlmp-32cpu-mpi.sh
    sbatch [+options] grex-runlmp-8tasks-4threads.sh

  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

* To do:

  - What are the CPU and memory efficiencies of each job? {use "seff -d <JOB ID>"}
  - compare the CPU and memory efficiencies of the different jobs?

