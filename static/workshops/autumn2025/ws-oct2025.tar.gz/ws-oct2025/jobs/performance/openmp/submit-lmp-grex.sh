#!/bin/bash

OPTS="--partition=genoa"

sbatch --cpus-per-task=1   ${OPTS} grex-runlmp-openmp.sh
sbatch --cpus-per-task=2   ${OPTS} grex-runlmp-openmp.sh
sbatch --cpus-per-task=4   ${OPTS} grex-runlmp-openmp.sh
sbatch --cpus-per-task=8   ${OPTS} grex-runlmp-openmp.sh
sbatch --cpus-per-task=16  ${OPTS} grex-runlmp-openmp.sh
sbatch --cpus-per-task=32  ${OPTS} grex-runlmp-openmp.sh
sbatch --cpus-per-task=64  ${OPTS} grex-runlmp-openmp.sh
