OpenMP job: example of benchmark for OpenMP job using lammps module
Requires: - lammps module
          - input file: lammps-input.in
          - Set OMP_NUM_THREADS

Restrictions: - On MC, the nodes have 16 CPUs. Therefore, it is not 
                possible to ask for more than 16 threads. 
              - On Grex, it depends on the partition:
                ==> up to 40 for largemem
                ==> up to 52 for skylake
                ==> up to 192 for genoa

grex-runlmp-16cpu-openmp.sh
grex-runlmp-2cpu-openmp.sh
grex-runlmp-4cpu-openmp.sh
grex-runlmp-8cpu-openmp.sh

* On MC/CC:

  - Inspect the script using: 

    cat mc-runlmp-2cpu-openmp.sh
    cat mc-runlmp-4cpu-openmp.sh
    cat mc-runlmp-8cpu-openmp.sh
    cat mc-runlmp-16cpu-openmp.sh

  - Submit the script using:

    sbatch mc-runlmp-2cpu-openmp.sh
    sbatch mc-runlmp-4cpu-openmp.sh
    sbatch mc-runlmp-8cpu-openmp.sh
    sbatch mc-runlmp-16cpu-openmp.sh
 
  - What is the job id for your job?

  - See if your job is on the queue by running: sq

* On Grex:
  + You need to specify the partition, like genoa with:

    --partition=genoa
  
  - Inspect the script using:
    cat grex-runlmp-16cpu-openmp.sh
    cat grex-runlmp-2cpu-openmp.sh
    cat grex-runlmp-4cpu-openmp.sh
    cat grex-runlmp-8cpu-openmp.sh

  - Submit the script using:
    sbatch [+options] grex-runlmp-16cpu-openmp.sh
    sbatch [+options] grex-runlmp-2cpu-openmp.sh
    sbatch [+options] grex-runlmp-4cpu-openmp.sh
    sbatch [+options] grex-runlmp-8cpu-openmp.sh

  - What is the job id for your job?

  - See if your job is on the queue by running: sq

* To do:

  - What are the CPU and memory efficiencies of each job? {use "seff -d <JOB ID>"}
  - compare the CPU and memory efficiencies of the different jobs?

