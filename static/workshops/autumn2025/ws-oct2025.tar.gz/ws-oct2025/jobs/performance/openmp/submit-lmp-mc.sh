#!/bin/bash

sbatch --cpus-per-task=1   mc-runlmp-openmp.sh
sbatch --cpus-per-task=2   mc-runlmp-openmp.sh
sbatch --cpus-per-task=4   mc-runlmp-openmp.sh
sbatch --cpus-per-task=8   mc-runlmp-openmp.sh
sbatch --cpus-per-task=16  mc-runlmp-openmp.sh
