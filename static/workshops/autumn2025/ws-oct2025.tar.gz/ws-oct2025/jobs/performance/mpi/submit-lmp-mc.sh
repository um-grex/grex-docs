#!/bin/bash

sbatch --ntasks-per-node=1   mc-runlmp-mpi.sh
sbatch --ntasks-per-node=2   mc-runlmp-mpi.sh
sbatch --ntasks-per-node=4   mc-runlmp-mpi.sh
sbatch --ntasks-per-node=8   mc-runlmp-mpi.sh
sbatch --ntasks-per-node=16  mc-runlmp-mpi.sh
sbatch --ntasks-per-node=32  mc-runlmp-mpi.sh
sbatch --ntasks-per-node=64  mc-runlmp-mpi.sh
