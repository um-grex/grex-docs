#!/bin/bash

OPTS="--partition=genoa"

#export SBATCH_ACCOUNT=""

sbatch --ntasks-per-node=1   ${OPTS} grex-runlmp-mpi.sh
sbatch --ntasks-per-node=2   ${OPTS} grex-runlmp-mpi.sh
sbatch --ntasks-per-node=4   ${OPTS} grex-runlmp-mpi.sh
sbatch --ntasks-per-node=8   ${OPTS} grex-runlmp-mpi.sh
sbatch --ntasks-per-node=16  ${OPTS} grex-runlmp-mpi.sh
sbatch --ntasks-per-node=32  ${OPTS} grex-runlmp-mpi.sh
sbatch --ntasks-per-node=64  ${OPTS} grex-runlmp-mpi.sh
