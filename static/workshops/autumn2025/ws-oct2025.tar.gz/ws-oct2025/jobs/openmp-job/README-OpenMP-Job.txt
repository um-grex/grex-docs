OpenMP job: example of OpenMP job using lammps module

Requires: - lammps module
          - input file: lammps-input.in
          - Set OMP_NUM_THREADS

NOTE: On MC, the max number of CPUs per node is 8.

* On MC/CC:

  - Inspect the script using: 
    cat mc-runlmp-2cpu-openmp.sh

  - Submit the script using:
    sbatch [+options] mc-runlmp-2cpu-openmp.sh
 
  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

* On Grex:
  + You need to specify the partition, like genoa with:

    --partition=genoa
  
  - Inspect the script using:
    cat grex-runlmp-2cpu-openmp.sh

  - Submit the script using:
    sbatch [+options] grex-runlmp-2cpu-openmp.sh

  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

