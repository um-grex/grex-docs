#!/bin/bash

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=1000M
#SBATCH --time=0-0:40:00
#SBATCH --job-name=OpenMP

# Load the modules:

module load StdEnv/2023  intel/2023.2.1  openmpi/4.1.5 lammps-omp/20240829

echo "Starting run at: `date`"

export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}

lmp -sf omp -in lammps-input.in -log output_lammps-openmp-${SLURM_CPUS_PER_TASK}cpus-${SLURM_JOBID}.txt

echo "Program finished with exit code $? at: `date`"
