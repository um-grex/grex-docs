GLOST: the Greedy Launcher Of Small Tasks.

* Glost Jobs: 
  In some case, we may need to submit mulitiple short jobs one 
  after. It is possible to run the commands one after another in a 
  single script. Glost uses the same technique but by running the 
  small jobs on different CPUs using MPI. Here, MPI distribute the 
  jobs among the available processes.

  Let's suppose, we have the commands: cmd0, cmd1, .... cmd999
 
  Using a single job, one can run:

  module load ...
  cmd0
  cmd1
  ...
  cmd999

  With glost, for example using 4 CPUs, it picks 4 first commands:
  cmd0, cmd1, cmd2, cmd3 and assigns one for each CPU.
  Once a task is done, glost will assign the next in the list
  ...
  etc
  ...

* There are two directories for tests:
  - single-dir: all the tasks run from the same directory. 
    Note: make sure that the output do not overlapp.

  - multiple-dir: each tasks run from a dedicated directory.
    Note: the output may have the same name and it will not create 
    problems as all the tasks run on separate directories.

* Running the jobs:

1. From the directory "single-dir:":

-  Go to the directory "single-dir"
   cd single-dir
   ls

- You will notice a file called: list_glost_tasks.txt

  Inspect this file using: cat list_glost_tasks.txt

  The file contains a list of tasks to run one after another.

  In this example, each task runs:

  narg=10 && sleep 220 && echo ${narg}-`hostname` > log_${narg}.txt

   Operations:
     - set a variable "narg" 
     - then run sleep command for some time
     - then prints the value of narg in a log file

- Submit the job using:

  On MC/CC: sbatch [+options] mc-run-glost.sh
  On Grex: sbatch [+options] grex-run-glost.sh

2. From the directory "multiple-dir:":

-  Go to the directory "multiple-dir"
   cd single-dir
   ls

- You will notice a file called: list_glost_tasks.txt

  Inspect this file using: cat list_glost_tasks.txt

  The file contains a list of tasks to run one after another.

  In this example, each task runs:
  
  narg=10 && mkdir -p ${narg} && cd ${narg} && sleep 220 && echo ${narg}-`hostname` > log_${narg}.txt

  Operations:
     - set a variable "narg"
     - then create a directory with a name as the value of the variable narg
     - then run sleep command for some time
     - then prints the value of narg in a log file

- Submit the job using:

  On MC/CC: sbatch [+options] mc-run-glost.sh
  On Grex: sbatch [+options] grex-run-glost.sh

