#!/bin/bash

#SBATCH --ntasks=8
#SBATCH --cpus-per-task=1
#SBATCH --mem=1000M
#SBATCH --time=0-0:40:00
#SBATCH --job-name=Glost

# Load the modules:

module load StdEnv/2023  gcc/12.3  openmpi/4.1.5 glost/0.3.1

echo "Starting run at: `date`"

echo "Running jobs using glost list: list_glost_tasks.txt"

mpirun -np ${SLURM_NTASKS} glost_launch list_glost_tasks.txt

echo "Program finished with exit code $? at: `date`"
