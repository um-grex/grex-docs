* Array Jobs: 
  In some case, we may need to submit mulitiple similar jobs for different 
  parameters, like different input files with indices: 0, .... N
  It is possible to achieve by submitting one script with the option:

  --array=<list of indices>

  and adapt the command line to use the indice labelled as: SLURM_ARRAY_TASK_ID

  When a job is submitted, it create a sub-job for each indice in the <list of indices>

* There are two directories for tests:
  - single-dir: all the sub-jobs run from the same directory. 
    Note: make sure that the output do not overlapp.

  - multiple-dir: all the sub-jobs run from a dedicated directory.
    Note: the output may have the same name and it will not create 
    problems as each sub-job runs on a separate directory.

* Running the jobs:

1. From the directory "single-dir:":

-  Go to the directory "single-dir"
   cd single-dir
   ls

- You will notice multiple input files: lammps-input-X.in where X=0,...,9

- Inspect the scripts:

  On MC: cat cc-runlmp-1cpu-jobarray.sh
  On Grex: grex-runlmp-1cpu-jobarray.sh

- Command line: 

  lmp -in lammps-input-${SLURM_ARRAY_TASK_ID}.in -log output_lammps-array-${SLURM_ARRAY_TASK_ID}-${SLURM_JOBID}.txt

- When submitting the job using:

  sbatch grex-runlmp-1cpu-jobarray.sh
  or
  sbatch cc-runlmp-1cpu-jobarray.sh

  The scheduler, will create 10 sub-jobs: JOBID_[0-9] 
  and each sub-job will use one input file: lammps-input-${SLURM_ARRAY_TASK_ID}.in
  and print the output to: output_lammps-array-${SLURM_ARRAY_TASK_ID}-${SLURM_JOBID}.txt

- Other ways to submit array jobs by adding the 
  option from the command line:

  * On Grex:

  + submit all sub-jobs:
  sbatch --array=0-9 grex-runlmp-1cpu-jobarray.sh

  + submit all sub-jobs and limit the maximum sub jobs to run at a time:
  sbatch --array=0-9%2 grex-runlmp-1cpu-jobarray.sh

  + submit particular sub-jobs: 0, 2, 3, 4, 5 and 9 
  sbatch --array=0,2-5,9 grex-runlmp-1cpu-jobarray.sh

  * On MC/CC:

  + submit all sub-jobs:
  sbatch --array=0-9 mc-runlmp-1cpu-jobarray.sh

  + submit all sub-jobs and limit the maximum sub jobs to run at a time:
  sbatch --array=0-9%2 mc-runlmp-1cpu-jobarray.sh
  
  + submit particular mc-jobs: 0, 2, 3, 4, 5 and 9
  sbatch --array=0,2-5,9 grex-runlmp-1cpu-jobarray.sh

2. From the directory "multiple-dir:":

  Do the same as in the previous directory "single-dir":

  - Inspect the scripts:
    grex-runlmp-1cpu-jobarray.sh
    mc-runlmp-1cpu-jobarray.sh

  - The differences are:
 
    * instead of having all input files in one directory, we created a directory 
      for each input file: Test_X where X=0,1, ...,9

    * In the script, there is an additional step to change the directory:
      cd Test_${SLURM_ARRAY_TASK_ID}

    Notes: There is no reason to have different names for the input and output 
           files since each job writes in a separate directory.

    * Submit the array jobs as discussed above {case: single-dir}.

   
