#!/bin/bash

#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=1000M
#SBATCH --time=0-0:30:00
#SBATCH --job-name=Array-Job
#SBATCH --array=0-9%2

# Load the modules:

module load arch/avx512  gcc/13.2.0  openmpi/4.1.6 lammps/2024-08-29p1

echo "Starting run at: `date`"

echo "Running LAMMPS using the input file: lammps-input-${SLURM_ARRAY_TASK_ID}.in"

cd Test_${SLURM_ARRAY_TASK_ID}

lmp -in lammps-input.in -log output_lammps-array-${SLURM_ARRAY_TASK_ID}-${SLURM_JOBID}.txt

echo "Program finished with exit code $? at: `date`"
