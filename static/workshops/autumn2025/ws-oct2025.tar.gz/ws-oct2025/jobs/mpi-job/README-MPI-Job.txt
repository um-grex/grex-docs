MPI job: example of MPI job using lammps module
Requires: - lammps module
          - input file: lammps-input.in

* On MC/CC:

  - Inspect the script using: 
    cat mc-runlmp-2cpu-mpi.sh

  - Submit the script using:
    sbatch [+options] mc-runlmp-2cpu-mpi.sh
 
  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

* On Grex:
  + You need to specify the partition, like genoa with:

    --partition=genoa
  
  - Inspect the script using:
    cat grex-runlmp-2cpu-mpi.sh

  - Submit the script using:
    sbatch [+options] grex-runlmp-2cpu-mpi.sh

  - What is the job id for your job?

  - See if your job is on the queue by running: sq

  - Inspect the output files: out* *.out

