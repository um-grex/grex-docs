* UManitoba Spring workshop - May 2025:

Directories: 

- workshop-program: program of the workshop.

- data-transfer: directory for data transfer using scp.

- modules: directory for using modules.

  + modules/quick-md-run: example of a short test on the 
    login node or interactive node using up to 4 CPUs. 

- jobs: directory for running jobs with slurm.

- software: directory for software and modules.   
