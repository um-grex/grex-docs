* Procedure to compile Treemix:

Note: the program requires boost and gcc

Home page: https://bitbucket.org/nygcresearch/treemix/wiki/Home

1. Download the version 1.13:

wget https://bitbucket.org/nygcresearch/treemix/downloads/treemix-1.13.tar.gz

2. Unpack the archive:

tar -xvf treemix-1.13.tar.gz 

3. Load gcc module.

* On MC/CC: module load gcc boost

* On Grex: module load arch/avx512 gcc boost

4. Go to the directory treemix-1.13, then configure and compile the program:

cd treemix-1.13
ls
./configure --prefix=${HOME}/software/treemix/1.13
make
make install

5. What to include in a job script:

load module
set path
command line

'''
module load gcc boost
export PATH=$PATH:${HOME}/software/treemix/1.13/bin
treemix --help
'''


