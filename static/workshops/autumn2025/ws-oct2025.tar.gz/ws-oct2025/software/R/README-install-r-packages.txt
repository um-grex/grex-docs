* Procedure to install R packages:

Note: requires to load R module and some dependencies.

For more information, use: module spider r

* Installing "sp" packages: 
- Requires: r, gdal, udunits
- Other packages may require additional external modules, like:
  gdal, geos, jags, gsl, proj, netcdf, udunits ... etc

1. Load r module and additional exaternal module: gdal, udunits

* On MC/CC: 
  module load gcc r gdal udunits

* On Grex: 
  module load arch/avx512  gcc/13.2.0 r/4.4.1+mkl-2024.1 gdal udunits

2. Use, module list, to see if the module is loaded.

3. Try to install the following packages using install.packages:

- First load the modules as discussed above.
- Launch R
- Install the package "sp"

module load gcc r gdal udunits
R

R version 4.4.0 (2024-04-24) -- "Puppy Cup"
Copyright (C) 2024 The R Foundation for Statistical Computing
Platform: x86_64-pc-linux-gnu

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

> Sys.setenv("DISPLAY"=":0.0")
> install.packages("sp")

For the first time, it asks a question:

'''
Warning in install.packages("sp") :
  'lib = "/cvmfs/soft.computecanada.ca/easybuild/software/2023/x86-64-v3/Compiler/gcccore/r/4.4.0/lib64/R/library"' is not writable
Would you like to use a personal library instead? (yes/No/cancel) 
'''

Answer by "yes"

Another question: answer by "yes"

Another question to select the mirror:
--- Please select a CRAN mirror for use in this session ---

Answer by "1" which corresponds to a mirror on cloud: 1: 0-Cloud [https]
Selection: 1
Then "Enter"

Other mirrors should work as well.

* For future installation, the first two questions will not be asked but 
you still have to select the mirror to use.

* The installation will start and at the end, you can run a quick test:

> library("sp")

* Continue with installing the rest of packages you may need and quit().

> quit()
Save workspace image? [y/n/c]: y

5. What to include in a job script:

load module
command line

'''
module load gcc r gdal udunits
Rscript computation.R
'''

