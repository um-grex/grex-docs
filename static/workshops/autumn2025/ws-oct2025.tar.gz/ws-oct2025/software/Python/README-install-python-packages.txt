* Procedure to install python packages:

Notes: Requires to load python module. 
       It may also need additional modules
       Use a virtual environment

For more information, use: module spider python

1. Load python module:

* On MC/CC: module load python

* On Grex: module load arch/avx512  gcc/13.2.0 python/3.12.9 

2. Use, module list, to see if the module is loaded.

3. Try to install the following package "cutadapt":

'''
module load python
virtualenv ~/my_venv
source ~/my_venv/bin/activate
pip install --upgrade pip 
pip install cutadapt

* For reference, you can take a snapshot of the list of packages installed:

pip freeze --local > ~/requirement-my_venv.txt

This list may help to reproduce the same installation later:

pip install -r ~/requirement-my_venv.txt

* For a quick test:

cutadapt --help

Then "deactivate" to exit from the virtual environment.

5. What to include in a job script:

load module
command line

'''
module load python {+any other module needed}
cutadapt {+options}
or
python your-program.py
'''


