* Software installation:

- Perl: Instructions to install perl packages

- Python: Instructions to install Python packages

- R: Instructions to install R packages

- STAR: Instructions to install STAR

- Treemix: Instructions to install trremix

- Trimmomatic: Instructions to install Trimmomatic
