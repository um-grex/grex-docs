* Procedure to compile STAR:

Home page: https://github.com/alexdobin/STAR

1. Download the version 2.7.11b from GitHub:

wget https://github.com/alexdobin/STAR/archive/refs/tags/2.7.11b.tar.gz

2. Unpack the archive:

tar -xvf 2.7.11b.tar.gz

3. Load gcc module.

* On MC/CC: module load gcc

* On Grex: module load arch/avx512 gcc

4. Go to the directory STAR-2.7.11b/source and compile the program:

cd STAR-2.7.11b/source/
ls
ls Makefile
make

- Look for the binary "STAR":

ls STAR

* Run STAR with --help option: 

./STAR --help

5. Set the path and test the code:

- Run the command 'realpath STAR' from the same directory from wher 
  you compiled the program: 

- Set the path:

export PATH=${PATHG}:/home/kerrache/Work/T0/STAR/STAR-2.7.11b/source

6. What to include in a job script:

load module
set path
command line

'''
module load gcc
export PATH=$PATH:${HOME}/Work/T0/STAR/STAR-2.7.11b/source
STAR --help

