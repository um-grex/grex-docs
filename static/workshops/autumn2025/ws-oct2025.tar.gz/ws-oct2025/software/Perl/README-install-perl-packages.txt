* Procedure to install perl packages:

Note: requires to load perl module.

For more information, use: module spider perl

1. Load perl module:

* On MC/CC: module load perl

* On Grex: module load arch/avx512 perl

2. Use, module list, to see if the module is loaded.

3. Try to install the following packages using cpan:

cpan install Hash::Merge

For the first installation, you will be asked to answer some questions:

'''
Loading internal logger. Log::Log4perl recommended for better logging

CPAN.pm requires configuration, but most of it can be done automatically.
If you answer 'no' below, you will enter an interactive dialog for each
configuration option instead.

Would you like to configure as much as possible automatically? [yes] 
'''
Answer by "yes"

Another question:

'''
CPAN.pm requires configuration, but most of it can be done automatically.
If you answer 'no' below, you will enter an interactive dialog for each
configuration option instead.

Would you like to configure as much as possible automatically? [yes] yes

Warning: You do not have write permission for Perl library directories.

To install modules, you need to configure a local Perl library directory or
escalate your privileges.  CPAN can help you by bootstrapping the local::lib
module or by configuring itself to use 'sudo' (if available).  You may also
resolve this problem manually if you need to customize your setup.

What approach do you want?  (Choose 'local::lib', 'sudo' or 'manual')
 [local::lib] 
'''

Answer: [local::lib]

* For future installation, the above questions will not be asked.

* The installation will start and at the end, you can run a quick test:

echo "use HTTP::Tiny;" > test.pl && perl test.pl

* Now, you can proceed with the installation of additional packages as needed:

cpan install <your package>

Note: if it asks for updating your ~/.bashrc, answer by "yes".
      This will add the path to perl packages to your environment.

5. What to include in a job script:

load module
command line

'''
module load perl
perl your-perl-program.pl
'''


