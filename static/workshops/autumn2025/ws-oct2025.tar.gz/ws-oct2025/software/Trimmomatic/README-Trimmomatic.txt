* Download Trimmomatic:

wget http://www.usadellab.org/cms/uploads/supplementary/Trimmomatic/Trimmomatic-0.39.zip

* Unpack the archive: Trimmomatic-0.39.zip

unzip Trimmomatic-0.39.zip 

* Load java modules:

- On MC/CC clusters:

module load java

- On Grex:

module load openjdk

* Run the code using:

java -jar <path to>/trimmomatic-0.39.jar

java -jar Trimmomatic-0.39/trimmomatic-0.39.jar --help

